
/*
SET UP -----------------------------------------------------------------------------------
*/
void setup() {
  // Configuracion puerto serie
  config_sp();
  digitalRead(A_enc_pin);
  // Configuracion OLED
  config_oled();

  // Configuracion PWM
  config_PWM();



  // Crear cola_enc
  cola_enc = xQueueCreate(TAM_COLA_I, TAM_MSG_I);
  if(cola_enc == NULL){
      Serial.println("Error en creacion de cola_enc");
      exit(-1);
  }

   //Crear la tarea task_enc
  if(xTaskCreatePinnedToCore( task_enc , "task_enc", 2048, NULL, 3, NULL,1) != pdPASS){
      Serial.println("Error en creacion tarea task_enc");
      exit(-1);
  }

  // Crear la tarea task_config
  if(xTaskCreatePinnedToCore( task_config , "task_config", 2048, NULL, 1, NULL,tskNO_AFFINITY) != pdPASS){
      Serial.println("Error en creacion tarea task_config");
      exit(-1);
  }

  // Crear la tarea task_loopcontr
  if(xTaskCreatePinnedToCore( task_loopcontr , "task_loopcontr", 2048, NULL, 3, NULL,1) != pdPASS){
      Serial.println("Error en creacion tarea task_loopcontr");
      exit(-1);
  }

   // Crear la tarea task_medidas
  if(xTaskCreatePinnedToCore( task_medidas , "task_medidas", 2048, NULL, 1, NULL,tskNO_AFFINITY) != pdPASS){
      Serial.println("Error en creacion tarea task_medidas");
      exit(-1);
  }


  #ifdef DEBUG_P1C
  // Crear la tarea task_medidas

  #endif

  // Configuracion del encoder
  config_enc();
  // Configuracion memoria eeprom
  ACTIVA_P1C_MED_ANG = 1;
  init_eeprom();

}

/*
 RUTINAS ATENCION INTERRUPCIONES ########################################################################
*/
/* 
 Rutina de atención a interrupción ISC_enc --------------------------------------------
*/
void IRAM_ATTR ISR_enc() {
  // Lee las salidas del Encoder    
  uint8_t a = digitalRead(A_enc_pin);
  uint8_t b = digitalRead(B_enc_pin);
  uint8_t r;
  // Procesa los datos    // r=2*a+b;
  if(a == 0 && b == 0){
      r = 1;
  }
  else if(a == 0 && b == 1){
      r = 2;
  }
  else if(a == 1 && b == 0){
      r = 3;
  }
  else if(a == 1 && b == 1){
      r = 4;
  }
  // Enviar los bytes a la cola 
  if (xQueueSendFromISR( cola_enc , &r ,NULL) != pdTRUE)
  {
      printf("Error de escritura en la cola cola_enc \n");
  }
}

////////////////////////////////////////////////////////////////////////////////////
// Funcion configuracion del encoder
////////////////////////////////////////////////////////////////////////////////////

void config_enc(){
    // Configuracion de pines del encoder
    pinMode(A_enc_pin, INPUT);
    pinMode(B_enc_pin, INPUT);
    // Configuracion interrupcion
    attachInterrupt(A_enc_pin, ISR_enc, CHANGE);
    attachInterrupt(B_enc_pin, ISR_enc, CHANGE);
} 

////////////////////////////////////////////////////////////////////////////////////
// Funcion configuracion del PWM
////////////////////////////////////////////////////////////////////////////////////

void config_PWM(){
    // Configuracion de pines de control PWM
    pinMode(PWM_f, OUTPUT);
    pinMode(PWM_r, OUTPUT);
    pinMode(2, OUTPUT);
    // Configuracion LED PWM 
    ledcSetup(pwmChannel, pwmfreq, pwmresolution);
    // Asignar el controlador PWM al GPIO
    ledcAttachPin(PWM_Pin, 0);
}  


////////////////////////////////////////////////////////////////////////////////////
// Funcion configuracion del puerto serie
////////////////////////////////////////////////////////////////////////////////////
void config_sp(){
    Serial.begin(115200);
    Serial.println("  ");
    Serial.println("--------------------------------------------");
    Serial.println("****** " NOMBRE_PRAC " ******");
    Serial.println("--------------------------------------------");
}  

////////////////////////////////////////////////////////////////////////////////////
// Funcion configuracion del OLED
////////////////////////////////////////////////////////////////////////////////////
void config_oled(){
    Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);
    display.begin(SSD1306_SWITCHCAPVCC, 0x3C) ;
    display.clearDisplay();
    display.setTextColor(WHITE);        // 
    display.setCursor(0,0);             // Start at top-left corner
    display.println(F("CONTR. MOTOR " NOMBRE_PRAC));
    display.display();
    delay(1000);
    display.setTextColor(BLACK,WHITE);        // 
    display.setCursor(0,20);             // Start at top-left corner
    display.println(F(" SW v." VERSION_SW));
    display.display();
    delay(1000);
}  


////////////////////////////////////////////////////////////////////////////////////
// Funcion de interpolacion LUT de Velocidad-Voltaje
////////////////////////////////////////////////////////////////////////////////////

float interpola_vel_vol_lut(float x) {
    // Buscar el valor superior más pequeño del array
    int8_t i = 0;
    if ( x >= Vel_LUT[LONG_LUT - 2] ) {i = LONG_LUT - 2;}
    else {while ( x > Vel_LUT[i+1] ) i++;}
  
    // Guardar valor superior e inferior
    float xL = Vel_LUT[i];
    float yL = Vol_LUT[i];
    float xR = Vel_LUT[i+1];
    float yR = Vol_LUT[i+1];
  
    // Interpolar
    float dydx = ( yR - yL ) / ( xR - xL );
  
    return yL + dydx * ( x - xL );
}
