/*
  Tarea imprimir por terminal del controlador  #####################################################################
*/

void task_medidas(void* arg)
{
  while (1) {
    if (start_stop == 1) {
      // Mostrar medidas de angulo y velocidad del motor

      if ( ACTIVA_P1C_MED_ANG == 1 ) { // Medida de angulo
        a_medida = (ang_cnt * 360) / 1200;
        Serial.print("M:");
        Serial.print(a_medida);
        Serial.print(" A:");
        Serial.print(ref_val, 2);

      } else { // Medida de velocidad
        Serial.print("M:");
        Serial.print(v_medida);
        Serial.print(" V:");
        Serial.print(ref_val, 2);

      }

      Serial.print(" VOLT:");
      Serial.print(volt, 2);

#ifdef ACTIVA_DEBUG
     // Serial.print(" MD: ");
      //Serial.print(ACTIVA_P1C_MED_ANG);
      Serial.print(" Vp:");
      Serial.print(V_p, 2);
      Serial.print(" Vi:");
      Serial.print(V_i, 2);
      //Serial.print(" Via:");
      //Serial.print(V_i_anterior, 2);

      Serial.print(" Kp:");
      Serial.print(K_p, 4);
      Serial.print(" Ti:");
      Serial.print(T_i, 3);
      Serial.print(" Td:");
      Serial.print(T_d, 4);
      Serial.print(" e:");
      Serial.print(error, 2);
      //Serial.print(" ZONA:");
      //Serial.print(voltdeadzone, 2);
      //Serial.print(" Fd:");
      //Serial.print(fd_bool);
            Serial.print(" Tcb:");
      Serial.print(Tcb);
      Serial.print(" Alpha:");
      Serial.print(alpha);
      Serial.print(" Vd:");
      Serial.print(V_d, 3);

#endif
      Serial.println("");

    } else {

    }

    // Activacion de la tarea cada 1s
    vTaskDelay(BLOQUEO_TAREA_MEDIDA_MS / portTICK_PERIOD_MS);
  }
}
