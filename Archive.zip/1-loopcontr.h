void proceso_rpm2();
/// Tareas prioridad ALTA
/*
 Tarea task_loopcontr #####################################################################
*/
void task_loopcontr(void* arg) {
  
	while(1) {		
    
      if(start_stop == 1){

        /*

          if( ACTIVA_P1C_MED_ANG == 1){  // MODO ANGULO 
              proceso_angulo(); 
          }else{  // MODO VELOCIDAD
              proceso_rpm2();   
          }

          // ---- Extras ----- 
          
         /* 
          if( ACTIVA_P1C_MED_ANG == 1){
              if(windup_state){
                windup_ang();
              } else {
                back_calculation_ang();
              }
          }else{
              if(windup_state){
                windup();
              } else {
               back_calculation();
              }
          }

     
          if( ACTIVA_P1C_MED_ANG == 1){  // MODO ANGULO 
              zona_muerta();
          }
          
          volt = V_p + V_i + V_d; 
          volt = volt+voltdeadzone;
          excita_motor(volt);
          */
        
      } else {
          puesta_a_cero();
    	}
    
		  // Activacion de la tarea cada 0.01s
	    vTaskDelay(BLOQUEO_TAREA_LOOPCONTR_MS / portTICK_PERIOD_MS);
	}
}


/*
 Tarea task_enc #####################################################################
*/
/* 
Tarea del lazo principal del controlador  #####################################################################
*/
void task_enc(void* arg) {
  // Declaracion de variables locales
  uint8_t r;
  uint8_t anterior;

  while(1){
    // Espera a leer los datos de la cola
    if (xQueueReceive( cola_enc , &r ,(TickType_t) portMAX_DELAY) == pdTRUE){
      // Codificar la fase del encoder
      if(r == 4){
        r = 3;
      }
      else if(r == 3){
        r = 4;
      }
      // Calcular incremento/decremento y actualizar valor 
      if(r > anterior){
        if(r == 4 && anterior == 1){
          ang_cnt--;
        }
        else{
          ang_cnt++;
        }
      }
      else{
        if(r == 1 && anterior ==4){
          ang_cnt++;
        }
        else{
          ang_cnt--;
        }
      }
      #ifdef DEBUG_P1A
        // Enviar al monitor serie
        Serial.println(ang_cnt); // STEPS
      #endif
      anterior = r;
     } else {
      printf("Error de lectura de la cola cola_enc \n");
     }
  
  }

}
