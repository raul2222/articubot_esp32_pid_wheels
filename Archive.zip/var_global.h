
#define EEPROM_SIZE 512
#define EE_1 0
#define EE_2 64
#define EE_3 128
#define ACTIVA_P1A
//#define DEBUG_P1A
#define ACTIVA_P1B1
#define ACTIVA_P1B2
#define ACTIVA_P1B3
#define ACTIVA_P1C
#define DEBUG_P1C
#define ACTIVA_P1D2
#define ACTIVA_P1D3
// Display OLED ///////////////////////////////////////////////////////////////////////////
#include <Adafruit_SSD1306.h>
#define SCREEN_WIDTH 128 // OLED display width, in pixels
#define SCREEN_HEIGHT 64 // OLED display height, in pixels
#define OLED_RESET     -1 // Reset pin # (or -1 if sharing Arduino reset pin)

// Parametros cola de la interrupcion del encoder ///////////////////////////////////////
#define TAM_COLA_I 1024 /*num mensajes*/
#define TAM_MSG_I 1 /*num caracteres por mensaje*/

// TIEMPOS
#define BLOQUEO_TAREA_LOOPCONTR_MS 10 
#define BLOQUEO_TAREA_MEDIDA_MS 10

// Configuración PWM  ////////////////////////////////////////////////////////////////////
uint32_t pwmfreq = 1000; // 1KHz
const uint8_t pwmChannel = 0;
const uint8_t pwmresolution = 8;
const int PWM_Max = pow(2,pwmresolution)-1; //

// Pines driver motor ///////////////A/////////////////////////////////////////////////////
#ifdef ACTIVA_R
const uint8_t PWM_Pin = 32; // Entrada EN // para mi controlador es la unica salida pwm
const uint8_t PWM_f = 4; // Entrada PWM1 // direccion
const uint8_t PWM_r = 14; // Entrada PWM2 // para mi controlador es enable

#else
const uint8_t PWM_Pin = 32; // Entrada EN 
const uint8_t PWM_f = 16; // Entrada PWM1 
const uint8_t PWM_r = 17; // Entrada PWM2 
#endif

// Voltaje maximo motor ////////////////////////////////////////////////////////////////////
float SupplyVolt = 12;

// Pines encoder ////////////////////////////////////////////////////////////////////
const uint8_t A_enc_pin = 35;
const uint8_t B_enc_pin = 34;

// Conversión a angulo y velocidad del Pololu 3072
//const float conv_rad = ; 
//const float conv_rev = ;
//const float conv_rad_grados = ; 
const float rpm_to_radians = 0.10471975512;
const float rad_to_deg = 57.29578;

// Declarar funciones ////////////////////////////////////////////////////////////////////
void config_sp(); // Configuracion puerto serie
void config_oled(); // Configuracion OLED
void config_enc(); // Configuracion del encoder
void config_PWM(); // Configuracion PWM
void excita_motor(float v_motor); // Excitacion motor con PWM
float interpola_vel_vol_lut(float x); // Interpolacion velocidad/voltios LUT
void proceso_angulo();
//void proceso_rpm();
void puesta_a_cero();


// TABLA VELOCIDAD-VOLTAJE P1D
#define LONG_LUT 12
//Vector de tensiones
const float Vol_LUT[LONG_LUT] = {0.6,  1 ,  1.5 , 2 ,  3,   4,  5,  6, 7, 8, 9, 100};
// Vector de velocidades
const float Vel_LUT[LONG_LUT] = {0.25,0.7, 1.12, 1.58, 2.5, 3.25, 4.1, 5, 5.91, 6.75,7.58,7.58 };

// Variables globales ////////////////////////////////////////////////////////////////////
int ACTIVA_P1C_MED_ANG = 1;
int32_t ang_cnt = 0;
float pwm_volt = 0;
int32_t pwm_motor = 0;
//int32_t sign_v_ant = 0;
float v_medida = 0;     // Valor medido de angulo o velocidad -----------------
float a_medida = 0;
float ref_val = 0;      // Valor de referencia de angulo o velocidad
int8_t start_stop = 0;  //1 -> en funcionamiento | 0 -> parado 
float K_p = 0;
float T_i = 0; // Ki
float T_d = 0; // Kd
int direccion = 0;
int direccion_ant = 0;  // variable global de función excita_motor
struct K_x {
  float kp;
  float ti;
  float td;
  float tcb;
  float alpha;
};


// Variables globales task_loopcontr ///////////////////////////////////////////////////////
float anterior = 0;
float V_i_anterior = 0;
float error = 0;
float volt = 0;
float V_p = 0;
float V_i = 0;
float V_d = 0;
float da = 0;
float error_anterior = 0;
bool windup_bool = false; bool windup_state = false;float windup_value = 9.1;
float Tcb = 2;
float V_i_windup = 0;
float voltdeadzone = 0; 

// Variables filtro derivativo
float alpha = 4.0;
bool fd_bool = 1;
float fd = 0;
float fd_anterior = 0;

// Declaracion objetos  ////////////////////////////////////////////////////////////////////
xQueueHandle cola_enc; // Cola encoder
